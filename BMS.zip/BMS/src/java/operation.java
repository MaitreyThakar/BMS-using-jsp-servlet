
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/operation")
public class operation extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String jdbcUrl = "jdbc:mysql://localhost:3306/bank"; // Change to your MySQL URL
        String username = "root"; // Change to your MySQL username
        String password = ""; // Change to your MySQL password

        String action = request.getParameter("action");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
                if ("insert".equalsIgnoreCase(action)) {
                    handleInsert(request, connection, response);
                } else if ("display".equalsIgnoreCase(action)) {
                    handleDisplay(request, connection, response);
                } else if ("search".equalsIgnoreCase(action)) {
                    handleSearch(request, connection, response);
                } else if ("update".equalsIgnoreCase(action)) {
                    handleUpdate(request, connection, response);
                } else if ("updatedata".equalsIgnoreCase(action)) {
                    handleUpdateData(request, connection, response);
                } else if ("delete".equalsIgnoreCase(action)) {
                    handleDelete(request, connection, response);
                } else if ("deleteall".equalsIgnoreCase(action)) {
                    handleDeleteAll(request, connection, response);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle any database errors
            response.sendRedirect("add.jsp?success=false");
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            System.err.println("MySQL JDBC driver not found.");
        }
    }

   private void handleInsert(HttpServletRequest request, Connection connection, HttpServletResponse response) throws  SQLException ,ServletException, IOException {
    String name = request.getParameter("name");
    String age = request.getParameter("age");
    String money = request.getParameter("money");
    String mobileno = request.getParameter("mobileno");
    String city = request.getParameter("city");
    String accno = request.getParameter("accno");

    // Validate and sanitize inputs here if needed
        // Check if the account already exists
        String selectSql = "SELECT * FROM `account` WHERE `ano` = ?";
        PreparedStatement selectStatement = connection.prepareStatement(selectSql);
            selectStatement.setInt(1, Integer.parseInt(accno));
            ResultSet rs = selectStatement.executeQuery();

            if (rs.next()) {    
                // Account already exists
                request.setAttribute("success", false);
                request.setAttribute("exists", true);
            } else {
                // Account doesn't exist; proceed with the insertion
                String insertSql = "INSERT INTO `account` (`ano`, `name`, `age`, `balance`, `mono`, `city`) VALUES (?,?,?,?,?,?)";
                try (PreparedStatement insertStatement = connection.prepareStatement(insertSql)) {
                    insertStatement.setInt(1, Integer.parseInt(accno));
                    insertStatement.setString(2, name);
                    insertStatement.setInt(3, Integer.parseInt(age));
                    insertStatement.setInt(4, Integer.parseInt(money));
                    insertStatement.setInt(5, Integer.parseInt(mobileno));
                    insertStatement.setString(6, city);

                    int rowsAffected = insertStatement.executeUpdate();

                    if (rowsAffected == 1) {
                        // Data inserted successfully
                        request.setAttribute("success", true);
                        request.setAttribute("exists", false);
                    } else {
                        // Data insertion failed
                        request.setAttribute("success", false);
                        request.setAttribute("exists", false);
                    }
                }
            }
                request.getRequestDispatcher("add.jsp").forward(request, response);

        }


    private void handleDisplay(HttpServletRequest request, Connection connection, HttpServletResponse response) throws SQLException, ServletException, IOException {
        // Handle display operation
        // ...

        // SQL query to fetch data from the database (adjust it as needed)
        String sql = "SELECT * FROM `account`";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        // Check if any results were returned
        if (resultSet.isBeforeFirst()) {
            request.setAttribute("searchres", true);
            request.setAttribute("Dataset", resultSet);

        } else {
            request.setAttribute("searchres", false);
            request.setAttribute("Dataset", null);

        }
        // Forward the request to an appropriate JSP page based on the result
        request.getRequestDispatcher("search.jsp").forward(request, response);
    }

    private void handleSearch(HttpServletRequest request, Connection connection, HttpServletResponse response) throws SQLException, ServletException, IOException {
        // Handle search operation
        // Handle search operation
        String accno = request.getParameter("accno"); // Get the data from the form
        String sql = "SELECT * FROM `account` WHERE `ano` = ?";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, Integer.parseInt(accno));
        ResultSet resultSet = preparedStatement.executeQuery();

        // Check if any results were returned
        if (resultSet.next()) {
            request.setAttribute("searchres", true);
            request.setAttribute("data", resultSet);

        } else {
            request.setAttribute("searchres", false);
            request.setAttribute("data", null);

        }

        // Forward the request to an appropriate JSP page based on the result
        // Forward the request to an appropriate JSP page based on the result
        request.getRequestDispatcher("search.jsp").forward(request, response);

    }

    private void handleUpdate(HttpServletRequest request, Connection connection, HttpServletResponse response) throws SQLException, ServletException, IOException {
        String accno = request.getParameter("accno");
        String sql = "SELECT * FROM `account` WHERE `ano` = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, Integer.parseInt(accno));
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            request.setAttribute("data", resultSet);
            request.setAttribute("updateres", false);
        } else {
            request.setAttribute("data", null);
            request.setAttribute("updateres", false);
        }

        request.getRequestDispatcher("update.jsp").forward(request, response);
    }

    private void handleUpdateData(HttpServletRequest request, Connection connection, HttpServletResponse response) throws SQLException, ServletException, IOException {
        String accno = request.getParameter("accno");
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String money = request.getParameter("money");
        String mobileno = request.getParameter("mobileno");
        String city = request.getParameter("city");

        String sql = "UPDATE `account` SET `name`=?,`age`=?,`balance`=?,`mono`=?,`city`=? WHERE `ano`=?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, Integer.parseInt(age));
        preparedStatement.setInt(3, Integer.parseInt(money));
        preparedStatement.setInt(4, Integer.parseInt(mobileno));
        preparedStatement.setString(5, city);
        preparedStatement.setInt(6, Integer.parseInt(accno));

        int result = preparedStatement.executeUpdate();

        if (result > 0) {
            request.setAttribute("updateres", true);
        } else {
            request.setAttribute("updateres", false);
        }

        request.getRequestDispatcher("update.jsp").forward(request, response);
    }

    private void handleDelete(HttpServletRequest request, Connection connection, HttpServletResponse response) throws SQLException, ServletException, IOException {
        String accno = request.getParameter("accno");
        String sql = "DELETE FROM `account` WHERE `ano` = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, Integer.parseInt(accno));
        int result = preparedStatement.executeUpdate();

        if (result > 0) {
            request.setAttribute("delete", true);
        } else {
            request.setAttribute("delete", null);
        }

        request.getRequestDispatcher("delete.jsp").forward(request, response);
    }

    private void handleDeleteAll(HttpServletRequest request, Connection connection, HttpServletResponse response) throws SQLException, ServletException, IOException {
        String sql = "DELETE FROM `account`";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        int result = preparedStatement.executeUpdate();

        if (result > 0) {
            request.setAttribute("deleteall", true);
        } else {
            request.setAttribute("delete", null);
        }

        request.getRequestDispatcher("delete.jsp").forward(request, response);
    }
}
